export const API_ROUTES = {

    GET_ALL_MENUS: "/menus",
    GET_MENU: "/menu/", // :id
    GET_MENU: "/menu/", // :id
    GET_PARENT_MENUS : "/parentmenus/", // :id OF the node
    DELETE_MENU: "/deletemenu/", // :id
    UPDATE_MENU: "/updatemenu",
    ADD_MENU: "/addmenu",
    
    


}